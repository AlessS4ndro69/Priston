<?php
  include(HTML_DIR . 'overall/header.php');
?>
<body>

<!-- Back to top button -->
<div class="back-to-top"></div>

<header>
  <nav class="navbar navbar-expand-lg navbar-light bg-white sticky" data-offset="500">
    <div class="container">
        
      <a href=base class="navbar-brand">Aprendo Fácil con <span class="text-primary">Priston.</span></a>

<?php
  include(HTML_DIR . 'overall/topnav.php');
?>
</header>  

<?php
  include(HTML_DIR . 'overall/body.php');
?>


<?php
  // en el body puedes enbeber funciones de php
  //include(HTML_DIR.'overall/gallery.php');
  include(HTML_DIR. 'overall/footer.php');
?>

</body>
</html>
