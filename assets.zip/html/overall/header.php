<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <!--<base href="http://localhost/Priston/">-->
  <base href="academiapriston.com">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">

  <!-- <meta name="copyright" content="MACode ID, https://macodeid.com/"> -->

  <title>Academia Priston - Forjando Futuro</title>

  <link rel="stylesheet" href="assets/css/maicons.css">

  <link rel="stylesheet" href="assets/css/bootstrap.css">

  <link rel="stylesheet" href="assets/vendor/animate/animate.css">

  <link rel="stylesheet" href="assets/css/theme.css">
  
  <link rel="stylesheet" href="assets/css/bootstrap-reboot.css">

  <link rel="stylesheet" href="assets/css/bootstrap-grid.css">

  <link rel="stylesheet" href="assets/css/form.css">

</head>
