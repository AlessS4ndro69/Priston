<?php
//include (HTML_DIR .'vistaPreviaCursos.html' );
?>

<?php
include (HTML_DIR .'publicidad.html' );
?>


  <div class="page-section">
    <div class="container">
      <div class="text-center wow fadeInUp">
        <div class="subhead">Planes</div>
        <h2 class="title-section">Elige el plan que más se acomode a ti</h2>
        <div class="divider mx-auto"></div>
      </div>
      <div class="row mt-5">
        
      <div class="col-lg-4 py-3 wow zoomIn">
          <div class="card-pricing">
            <div class="header">
              <div class="pricing-type">Ciclo Anual</div>
              <div class="price">
                <span class="dollar">S/.</span>
                <h1>69<span class="suffix">.00</span></h1>
              </div>
              <h5>Al mes</h5>
            </div>
            <div class="body">
              <p>Clases en vivo <span class="suffix"></span></p>
              <p>Mas de 100 videos explicativos  <span class="suffix"></span></p>
              <p>Teoria y práctica <span class="suffix"></span></p>
              <p>Material en pdf <span class="suffix"></span></p>
              <p>24 horas disponible <span class="suffix"></span></p>
              <p>Ranking todos los meses<span class="suffix"> </span></p>
              <p>Becas para los mejores alumnos<span class="suffix"></span></p>
              <p>Duración de 4 meses <span class="suffix"></span></p>
            </div>
            <div class="footer">
            <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#ModalSubscribe" data-whatever="@mdo">Subscribe</button>


            <div class="modal fade" id="ModalSubscribe" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
              <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                      <h5 class="modal-title" id="ModalSubscribe">Ingresa tus datos</h5>
                      <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                      </button>
                    </div>
                  <div class="modal-body">
                  <?php
                    include(HTML_DIR . 'formSubscribe.html');
                  ?>
                  
                  </div>
                  <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
                    <button type="button" class="btn btn-primary" onclick="validate()">Iniciar</button>
                  </div>
                </div>
              </div>
            </div>

              </div>
              </div>
            </div>
        <div class="col-lg-4 py-3 wow zoomIn">
          <div class="card-pricing marked">
            <div class="header">
              <div class="pricing-type">Ciclo Verano Pre-inscripción</div>
              <div class="price">
                <span class="dollar">S/.</span>
                <h1>130<span class="suffix">.00</span></h1>
              </div>
              <h5>Único pago</h5>
            </div>
            <div class="body">
              <p>Clases en vivo<span class="suffix"> </span></p>
              <p>Material de estudio<span class="suffix"></span></p>
              <p>Ejercicios en clase<span class="suffix"> </span></p>
              <p>Disponibilidad de videos 24/7<span class="suffix"> </span></p>
              <p>Biblioteca virtual<span class="suffix"> </span></p>
              <p>Duración de 5 semanas<span class="suffix"> </span></p>
            </div>
            <div class="footer">
            

            <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#ModalSubscribe" data-whatever="@mdo">Inscripción</button>


            <div class="modal fade" id="ModalSubscribe" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
              <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                      <h5 class="modal-title" id="ModalSubscribe">Ingresa tus datos</h5>
                      <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                      </button>
                    </div>
                  <div class="modal-body">
                  <?php
                    include(HTML_DIR . 'formSubscribe.html');
                  ?>
                  
                  </div>
                  <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
                    <button type="button" class="btn btn-primary" onclick="validate()">Iniciar</button>
                  </div>
                </div>
              </div>
            </div>
        	</div>
        </div>
          </div>
        
              <div class="col-lg-4 py-3 wow zoomIn">
              <div class="card-pricing">
                <div class="header">
                  <div class="pricing-type">Ciclo Pre-policial</div>
                  <div class="price">
                    <span class="dollar">S/.</span>
                    <h1>200.<span class="suffix">.00</span></h1>
                  </div>
                  <h5>Al mes</h5>
                </div>
                <div class="body">
                  <p>Clases de Razonamiento Matemático<span class="suffix"></span></p>
                  <p>Clases de Psicotécnico<span class="suffix"> </span></p>
                  <p>100% Práctico resolución de ejercicios </span></p>
                  <p>Material de estudio<span class="suffix"> </span></p>
                  <p>Duración de dos meses<span class="suffix"> </span></p>
                  
                  
                </div>
                <div class="footer">
                

                <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#ModalSubscribe" data-whatever="@mdo">Subscribe</button>


                <div class="modal fade" id="ModalSubscribe" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                  <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                          <h5 class="modal-title" id="ModalSubscribe">Ingresa tus datos</h5>
                          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                          </button>
                        </div>
                      <div class="modal-body">
                      <?php
                        include(HTML_DIR . 'formSubscribe.html');
                      ?>
                      
                      </div>
                      <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
                        <button type="button" class="btn btn-primary" onclick="validate()">Iniciar</button>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              </div>
            </div>
        
        
          </div>
        </div>

      </div>
    </div>  <!--.container --> 
  </div>  <!--.page-section --> 

  <!-- Banner info -->
  <div class="page-section banner-info">
    <div class="wrap bg-image" style="background-image: url(assets/img/bg_pattern.svg);">
      <div class="container">
        <div class="row align-items-center">
          <div class="col-lg-6 py-3 pr-lg-5 wow fadeInUp">
            <h2 class="title-section">Cambiamos el método de  <br> Educación</h2>
            <div class="divider"></div>
            <p>Forma parte de esta comunidad estudiantil y supera tus retos.</p>
            
            <ul class="theme-list theme-list-light text-white">
              <li>
                <div class="h5">Preparación para examenes de admisión</div>
                <p>Inicio de nuevo grupo los dias Lunes</p>
              </li>
              <li>
                <div class="h5">Preparación para la policia, militarizada</div>
                <p>Inicio de nuevo grupo los dias Martes</p>
              </li>
            </ul>
          </div>
          <div class="col-lg-6 py-3 wow fadeInRight">
            <div class="img-fluid text-center">
              <img src="assets/img/banner_image_2.svg" alt="">
            </div>
          </div>
        </div>
      </div>
    </div> <!-- .wrap -->
  </div> <!-- .page-section --> 
 
