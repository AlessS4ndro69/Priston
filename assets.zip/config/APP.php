<?php
    const SERVERURL= "http://localhost/Priston/";
    const COMPANY = "Academia Priston";
    const MONEDA = "$";
    date_default_timezone_set("America/Lima"); 
