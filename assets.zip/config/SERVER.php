<?php

const SERVER = "localhost";
const DB = "academia_priston";
const USER = "academia_root";
const PASS = "VewUn@N&X35H";
const SGBD = "mysql:host =" . SERVER . "dbname=" . DB ;

const METHOD = "AES-256-CBC";
const SECRET_KEY = '$PRESTAMOS@2020';
const SECRET_IV = '11235813';